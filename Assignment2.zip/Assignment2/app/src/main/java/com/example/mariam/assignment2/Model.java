package com.example.mariam.assignment2;

import android.util.Log;

import java.util.Stack;

public class Model
{
    public float sum;
    private char operator;
    String concat;

    Stack<Float> stack = new Stack<Float>();

    Model()
    {
        sum = 0.0f;
        concat = "0";
    }

    public float getSum()
    {
        return sum;
    }

    public void setSum(float value)
    {
        sum = value;
    }


    public boolean identify(char tag, char prev)
    {
        boolean bool = false;
        switch (tag) {
            case '0':
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
            case '7':
            case '8':
            case '9':
                concat = concat + tag;
                bool = true;
                break;
            case '−':
                concat = String.valueOf(Float.parseFloat(concat) * (-1.0f) );
                bool = true;
                break;
            case '.':
                concat = concat + tag;
                bool = true;
                break;

            case '%':
            case '+':
            case '-':
            case 'x':
            case '/':
//                Log.i("what", "prev "+ prev);
                if(!concat.isEmpty()) {
                    float wut = Float.parseFloat(concat);
                    stack.push(wut);
                    concat = "0";
                    if (stack.size() == 2 || tag=='%') {
                        operate(operator);
                        //stack.clear();
                        //stack.push(ans);
                    }
                    operator = tag;
                    bool =  true;
                }
                break;

        }
        return bool;
    }


    public void operate(char tag)
        {
            switch (tag)
            {
                case '+':
                    float numm1 = (stack.pop());
                    float numm2 = (stack.pop());
                    stack.push(numm1 + numm2);
                    setSum(numm1 + numm2);
                    break;
                case '-':
                    numm1 = (stack.pop());
                    numm2 = (stack.pop());
                    stack.push(numm2 - numm1);
                    setSum(numm2 - numm1);
                    break;
                case 'x':
                    numm1 = (stack.pop());
                    numm2 = (stack.pop());
                    stack.push(numm1 * numm2);
                    setSum(numm1 * numm2);
                    break;
                case '/':
                    numm1 = (stack.pop());
                    numm2 = (stack.pop());
                    stack.push(numm2 / numm1);
                    setSum(numm2 / numm1);
                    break;
                case '%':
                    numm1 = (Float)stack.pop();
                    numm2 = 100.0f;
                    stack.push((Float)numm1 / (Float)numm2);
                    Log.i("what", (Float)numm1 + " the ans is "+ (Float)numm1/(Float)numm2);
                    setSum((Float)numm1 / (Float)numm2);
                    break;
            }

        }


    public boolean isClear(char tag)
    {
        if(tag == 'c')
        {
            stack.clear();
            concat = "0";
            sum = 0.0f;
            return true;
        }
        else if(tag == '=')
        {
            //Log.i("what", concat + "well well well "+concat);
            if(!concat.isEmpty())
            {
                float wutz = Float.parseFloat(concat);
                stack.push(wutz);
                concat = "0";
                Log.i("what", "operator  " + operator);
                if (stack.size() == 2 || operator=='%') {
                    operate(operator);
                }
            }
            else
                setSum(getSum());
            return true;

        }
        return false;
    }

}
