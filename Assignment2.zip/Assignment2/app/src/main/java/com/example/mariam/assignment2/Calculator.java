package com.example.mariam.assignment2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class Calculator extends AppCompatActivity implements View.OnClickListener{

    Model model;

    TextView output;
    TextView operation;

    ImageButton zero;
    ImageButton one;
    ImageButton two;
    ImageButton three;
    ImageButton four;
    ImageButton five;
    ImageButton six;
    ImageButton seven;
    ImageButton eight;
    ImageButton nine;

    ImageButton del;
    ImageButton sub;
    ImageButton add;
    ImageButton mod;
    ImageButton div;
    ImageButton dec;
    ImageButton sign;
    ImageButton eq;
    ImageButton mult;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        model = new Model();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);

        this.output = (TextView) findViewById(R.id.out);
        this.operation = (TextView) findViewById(R.id.operation);

        zero = (ImageButton) findViewById(R.id.zero);
        one = (ImageButton) findViewById(R.id.one);
        two = (ImageButton) findViewById(R.id.two);
        three = (ImageButton) findViewById(R.id.three);
        four = (ImageButton) findViewById(R.id.four);
        five = (ImageButton) findViewById(R.id.five);
        six = (ImageButton) findViewById(R.id.six);
        seven = (ImageButton) findViewById(R.id.seven);
        eight = (ImageButton) findViewById(R.id.eight);
        nine = (ImageButton) findViewById(R.id.nine);

        del = (ImageButton) findViewById(R.id.c);
        sub = (ImageButton) findViewById(R.id.minus);
        add = (ImageButton) findViewById(R.id.plus);
        mod = (ImageButton) findViewById(R.id.modulus);
        div = (ImageButton) findViewById(R.id.divide);
        dec = (ImageButton) findViewById(R.id.decimal);
        sign = (ImageButton) findViewById(R.id.plusminus);
        eq = (ImageButton) findViewById(R.id.equals);
        mult = (ImageButton) findViewById(R.id.multiply);

        zero.setOnClickListener(this);
        one.setOnClickListener(this);
        two.setOnClickListener(this);
        three.setOnClickListener(this);
        four.setOnClickListener(this);
        five.setOnClickListener(this);
        six.setOnClickListener(this);
        seven.setOnClickListener(this);
        eight.setOnClickListener(this);
        nine.setOnClickListener(this);

        del.setOnClickListener(this);
        sub.setOnClickListener(this);
        add.setOnClickListener(this);
        mod.setOnClickListener(this);
        div.setOnClickListener(this);
        dec.setOnClickListener(this);
        sign.setOnClickListener(this);
        eq.setOnClickListener(this);
        mult.setOnClickListener(this);

        zero.setTag('0');
        one.setTag('1');
        two.setTag('2');
        three.setTag('3');
        four.setTag('4');
        five.setTag('5');
        six.setTag('6');
        seven.setTag('7');
        eight.setTag('8');
        nine.setTag('9');

        del.setTag('c');
        sub.setTag('-');
        add.setTag('+');
        mod.setTag('%');
        div.setTag('/');
        dec.setTag('.');
        sign.setTag('−');
        eq.setTag('=');
        mult.setTag('x');


    }

    @Override
    public void onClick(View v) {

        char prev = ' ';
        char tag = (char)v.getTag();
        if(model.isClear(tag))
        {
            operation.setText("");
            output.setText(String.valueOf(model.getSum()));
        }
        else
        {

            if(model.identify(tag,prev))
            {
                output.setText(Float.toString(model.getSum()));
                operation.append(String.valueOf(tag));
            }
            prev = tag;
        }


    }
}
